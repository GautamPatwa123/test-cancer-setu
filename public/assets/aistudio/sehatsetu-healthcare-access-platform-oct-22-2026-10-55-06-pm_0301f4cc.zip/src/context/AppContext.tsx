import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  PageId,
  Language,
  UserRole,
  PatientProfile,
  BloodCentre,
  AmbulanceProvider,
  NgoListing,
  GovernmentScheme,
  HospitalListing,
  BloodRequest,
  AmbulanceRequest,
  AssistanceApplication,
  MedicalDoc,
  AuditLog,
  RequestStatus,
  AmbulanceStatus,
  AssistanceStatus,
  BloodGroup,
  BloodComponent,
  UserLocation,
  VolunteerDonor,
} from '../types/index.ts';
import {
  INITIAL_PATIENT,
  INITIAL_BLOOD_CENTRES,
  INITIAL_AMBULANCES,
  INITIAL_DOCUMENTS,
  INITIAL_BLOOD_REQUESTS,
  INITIAL_AMBULANCE_REQUESTS,
  INITIAL_ASSISTANCE_APPLICATIONS,
  INITIAL_NGOS,
  INITIAL_GOVT_SCHEMES,
  INITIAL_HOSPITALS,
  INITIAL_AUDIT_LOGS,
  INITIAL_VOLUNTEER_DONORS,
} from '../data/mockData.ts';
import { generateSecureShareToken, maskPreciseCoordinates, formatApproximateArea } from '../utils/healthLogic.ts';
import { translations } from '../translations/index.ts';

interface AppContextType {
  currentPage: PageId;
  setCurrentPage: (page: PageId) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: keyof typeof translations['en']) => string;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  selectedCity: string;
  setSelectedCity: (city: string) => void;
  publicQrPreviewToken: string | null;
  setPublicQrPreviewToken: (token: string | null) => void;

  userLocation: UserLocation;
  setUserLocation: (loc: UserLocation) => void;
  requestBrowserLocation: () => Promise<{ success: boolean; message: string }>;
  setManualLocation: (state: string, city: string, locality?: string) => void;
  clearLocation: () => void;

  volunteerDonors: VolunteerDonor[];
  toggleDonorOptIn: (donorId: string) => void;
  registerVolunteerDonor: (data: Omit<VolunteerDonor, 'id' | 'lastActive'>) => VolunteerDonor;

  patient: PatientProfile;
  updatePatientProfile: (updated: Partial<PatientProfile>) => void;
  toggleSharedField: (field: keyof PatientProfile['sharedFields']) => void;
  regenerateQrToken: () => void;
  revokeQrToken: () => void;

  bloodCentres: BloodCentre[];
  ambulances: AmbulanceProvider[];
  documents: MedicalDoc[];
  bloodRequests: BloodRequest[];
  ambulanceRequests: AmbulanceRequest[];
  assistanceApplications: AssistanceApplication[];
  ngos: NgoListing[];
  govtSchemes: GovernmentScheme[];
  hospitals: HospitalListing[];
  auditLogs: AuditLog[];

  createBloodRequest: (data: Omit<BloodRequest, 'id' | 'createdAt' | 'updatedAt' | 'history' | 'status'>) => BloodRequest;
  updateBloodRequestStatus: (requestId: string, newStatus: RequestStatus, note?: string) => void;

  createAmbulanceRequest: (data: Omit<AmbulanceRequest, 'id' | 'createdAt' | 'updatedAt' | 'history' | 'status'>) => AmbulanceRequest;
  updateAmbulanceRequestStatus: (requestId: string, newStatus: AmbulanceStatus, note?: string) => void;

  createAssistanceApplication: (data: Omit<AssistanceApplication, 'id' | 'createdAt' | 'updatedAt' | 'history' | 'status'>) => AssistanceApplication;
  updateAssistanceStatus: (appId: string, newStatus: AssistanceStatus, note?: string) => void;

  uploadDocument: (doc: Omit<MedicalDoc, 'id' | 'uploadedAt'>) => MedicalDoc;
  updateDocumentAiExplanation: (docId: string, explanation: MedicalDoc['aiExplanation']) => void;

  resetAllDemoData: () => void;
  showResetConfirmModal: boolean;
  setShowResetConfirmModal: (show: boolean) => void;
}

const STORAGE_KEY = 'sehatsetu_data_v2';

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentPage, setCurrentPage] = useState<PageId>('landing');
  const [language, setLanguage] = useState<Language>('en');
  const [userRole, setUserRole] = useState<UserRole>('patient');
  const [selectedCity, setSelectedCity] = useState<string>('Darbhanga, Bihar');
  const [publicQrPreviewToken, setPublicQrPreviewToken] = useState<string | null>(null);
  const [showResetConfirmModal, setShowResetConfirmModal] = useState<boolean>(false);

  // User location preference (manual selection by default, or browser GPS after explicit button click)
  const [userLocation, setUserLocation] = useState<UserLocation>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_user_location`);
      return saved
        ? JSON.parse(saved)
        : {
            type: 'manual',
            state: 'Bihar',
            city: 'Darbhanga',
            approximateArea: 'Darbhanga, Bihar',
            isPermissionGranted: false,
          };
    } catch {
      return {
        type: 'manual',
        state: 'Bihar',
        city: 'Darbhanga',
        approximateArea: 'Darbhanga, Bihar',
        isPermissionGranted: false,
      };
    }
  });

  // Volunteer donor community registry with opt-in status
  const [volunteerDonors, setVolunteerDonors] = useState<VolunteerDonor[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_donors`);
      return saved ? JSON.parse(saved) : INITIAL_VOLUNTEER_DONORS;
    } catch {
      return INITIAL_VOLUNTEER_DONORS;
    }
  });

  // Load from local storage or defaults
  const [patient, setPatient] = useState<PatientProfile>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_patient`);
      return saved ? JSON.parse(saved) : INITIAL_PATIENT;
    } catch {
      return INITIAL_PATIENT;
    }
  });

  const [bloodCentres, setBloodCentres] = useState<BloodCentre[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_blood_centres`);
      return saved ? JSON.parse(saved) : INITIAL_BLOOD_CENTRES;
    } catch {
      return INITIAL_BLOOD_CENTRES;
    }
  });

  const [ambulances, setAmbulances] = useState<AmbulanceProvider[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_ambulances`);
      return saved ? JSON.parse(saved) : INITIAL_AMBULANCES;
    } catch {
      return INITIAL_AMBULANCES;
    }
  });

  const [documents, setDocuments] = useState<MedicalDoc[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_documents`);
      return saved ? JSON.parse(saved) : INITIAL_DOCUMENTS;
    } catch {
      return INITIAL_DOCUMENTS;
    }
  });

  const [bloodRequests, setBloodRequests] = useState<BloodRequest[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_blood_requests`);
      return saved ? JSON.parse(saved) : INITIAL_BLOOD_REQUESTS;
    } catch {
      return INITIAL_BLOOD_REQUESTS;
    }
  });

  const [ambulanceRequests, setAmbulanceRequests] = useState<AmbulanceRequest[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_ambulance_requests`);
      return saved ? JSON.parse(saved) : INITIAL_AMBULANCE_REQUESTS;
    } catch {
      return INITIAL_AMBULANCE_REQUESTS;
    }
  });

  const [assistanceApplications, setAssistanceApplications] = useState<AssistanceApplication[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_assistance_apps`);
      return saved ? JSON.parse(saved) : INITIAL_ASSISTANCE_APPLICATIONS;
    } catch {
      return INITIAL_ASSISTANCE_APPLICATIONS;
    }
  });

  const [hospitals, setHospitals] = useState<HospitalListing[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_hospitals`);
      return saved ? JSON.parse(saved) : INITIAL_HOSPITALS;
    } catch {
      return INITIAL_HOSPITALS;
    }
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_audit_logs`);
      return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
    } catch {
      return INITIAL_AUDIT_LOGS;
    }
  });

  // Persistent storage side-effects
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_user_location`, JSON.stringify(userLocation));
      localStorage.setItem(`${STORAGE_KEY}_donors`, JSON.stringify(volunteerDonors));
      localStorage.setItem(`${STORAGE_KEY}_patient`, JSON.stringify(patient));
      localStorage.setItem(`${STORAGE_KEY}_blood_centres`, JSON.stringify(bloodCentres));
      localStorage.setItem(`${STORAGE_KEY}_ambulances`, JSON.stringify(ambulances));
      localStorage.setItem(`${STORAGE_KEY}_documents`, JSON.stringify(documents));
      localStorage.setItem(`${STORAGE_KEY}_blood_requests`, JSON.stringify(bloodRequests));
      localStorage.setItem(`${STORAGE_KEY}_ambulance_requests`, JSON.stringify(ambulanceRequests));
      localStorage.setItem(`${STORAGE_KEY}_assistance_apps`, JSON.stringify(assistanceApplications));
      localStorage.setItem(`${STORAGE_KEY}_hospitals`, JSON.stringify(hospitals));
      localStorage.setItem(`${STORAGE_KEY}_audit_logs`, JSON.stringify(auditLogs));
    } catch (e) {
      console.warn('Failed to persist to localStorage:', e);
    }
  }, [
    userLocation,
    volunteerDonors,
    patient,
    bloodCentres,
    ambulances,
    documents,
    bloodRequests,
    ambulanceRequests,
    assistanceApplications,
    hospitals,
    auditLogs,
  ]);

  const t = (key: keyof typeof translations['en']): string => {
    return translations[language][key] || translations['en'][key] || String(key);
  };

  const addAuditLog = (entityType: AuditLog['entityType'], action: string, details: string) => {
    const newLog: AuditLog = {
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'short', timeStyle: 'short' }),
      action,
      entityType,
      actor: userRole === 'admin' ? 'Dr. Anand Verma (Admin)' : `${patient.name} (Patient)`,
      details,
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  const requestBrowserLocation = async (): Promise<{ success: boolean; message: string }> => {
    if (typeof window === 'undefined' || !navigator.geolocation) {
      return {
        success: false,
        message: 'Browser geolocation is not available on this device. Manual state and city selection is enabled.',
      };
    }

    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const { latitude, longitude, accuracy } = pos.coords;
          const { approxLat, approxLon } = maskPreciseCoordinates(latitude, longitude);
          const approxLabel = `Approx. Area (${approxLat.toFixed(2)}° N, ${approxLon.toFixed(2)}° E)`;
          const newLoc: UserLocation = {
            type: 'geolocation',
            state: 'Bihar',
            city: 'Darbhanga',
            approximateArea: approxLabel,
            latitude,
            longitude,
            accuracyMeters: Math.round(accuracy),
            timestamp: new Date().toISOString(),
            isPermissionGranted: true,
          };
          setUserLocation(newLoc);
          addAuditLog(
            'Security',
            'GPS_LOCATION_ACCESSED',
            `User authorized browser geolocation via 'Use my location' button. Approximate grid (${approxLat}, ${approxLon}) used for nearby care distances.`
          );
          resolve({ success: true, message: `Location detected: ${approxLabel}` });
        },
        (err) => {
          let msg = 'Location request was declined. You can select your Indian state and city manually below.';
          if (err.code === err.PERMISSION_DENIED) {
            msg = 'Location permission was denied. The platform continues to function fully using manual city selection.';
          }
          addAuditLog('Security', 'GPS_PERMISSION_DENIED', `Browser geolocation request was not granted (${err.message}). Manual fallback active.`);
          resolve({ success: false, message: msg });
        },
        { enableHighAccuracy: false, timeout: 8000, maximumAge: 300000 }
      );
    });
  };

  const setManualLocation = (state: string, city: string, locality?: string) => {
    const area = formatApproximateArea(city, state, locality);
    const newLoc: UserLocation = {
      type: 'manual',
      state,
      city,
      approximateArea: area,
      // Landmark approximate coordinates for prominent cities
      latitude: city.toLowerCase() === 'darbhanga' ? 26.1542 : undefined,
      longitude: city.toLowerCase() === 'darbhanga' ? 85.8918 : undefined,
      isPermissionGranted: false,
    };
    setUserLocation(newLoc);
    setSelectedCity(`${city}, ${state}`);
    addAuditLog('Profile', 'MANUAL_LOCATION_SET', `User manually chose ${area}. Precise GPS coordinates cleared.`);
  };

  const clearLocation = () => {
    const cleared: UserLocation = {
      type: 'manual',
      state: 'Bihar',
      city: 'Darbhanga',
      approximateArea: 'Darbhanga, Bihar (Default)',
      isPermissionGranted: false,
    };
    setUserLocation(cleared);
    setSelectedCity('Darbhanga, Bihar');
    addAuditLog('Security', 'LOCATION_CLEARED', 'Location information and any stored coordinates reset to default.');
  };

  const toggleDonorOptIn = (donorId: string) => {
    setVolunteerDonors((prev) =>
      prev.map((d) => {
        if (d.id !== donorId) return d;
        const nextOpt = !d.optedIn;
        addAuditLog(
          'Security',
          'DONOR_OPT_IN_STATUS',
          `Volunteer donor ${d.alias} availability changed to: ${nextOpt ? 'Opted-In (Active)' : 'Withdrawn / Paused'}`
        );
        return {
          ...d,
          optedIn: nextOpt,
          lastActive: nextOpt ? 'Active today' : 'Availability paused',
        };
      })
    );
  };

  const registerVolunteerDonor = (data: Omit<VolunteerDonor, 'id' | 'lastActive'>): VolunteerDonor => {
    const newDonor: VolunteerDonor = {
      ...data,
      id: `DONOR-VOL-${Date.now()}`,
      lastActive: 'Registered today',
    };
    setVolunteerDonors((prev) => [newDonor, ...prev]);
    addAuditLog(
      'Blood',
      'VOLUNTEER_DONOR_REGISTERED',
      `Registered volunteer donor ${data.alias} for blood group ${data.bloodGroup} in ${data.approximateArea}. Private phone protected.`
    );
    return newDonor;
  };

  const updatePatientProfile = (updated: Partial<PatientProfile>) => {
    setPatient((prev) => ({ ...prev, ...updated }));
    addAuditLog('Profile', 'PROFILE_UPDATED', 'Patient medical profile fields updated');
  };

  const toggleSharedField = (field: keyof PatientProfile['sharedFields']) => {
    setPatient((prev) => ({
      ...prev,
      sharedFields: {
        ...prev.sharedFields,
        [field]: !prev.sharedFields[field],
      },
    }));
    addAuditLog('Security', 'QR_PERMISSIONS_CHANGED', `Field "${String(field)}" toggled in emergency QR profile`);
  };

  const regenerateQrToken = () => {
    const { token, expiryIso } = generateSecureShareToken(patient.name);
    setPatient((prev) => ({
      ...prev,
      qrToken: token,
      qrTokenExpiry: expiryIso,
      qrActive: true,
    }));
    addAuditLog('Security', 'QR_TOKEN_REGENERATED', `New emergency token ${token} created with 48hr expiry`);
  };

  const revokeQrToken = () => {
    setPatient((prev) => ({
      ...prev,
      qrActive: false,
    }));
    addAuditLog('Security', 'QR_TOKEN_REVOKED', 'Active QR share link revoked. Access blocked.');
  };

  const createBloodRequest = (data: Omit<BloodRequest, 'id' | 'createdAt' | 'updatedAt' | 'history' | 'status'>): BloodRequest => {
    const now = new Date().toISOString().slice(0, 16).replace('T', ' ');
    const newReq: BloodRequest = {
      ...data,
      id: `REQ-BLD-${Math.floor(1000 + Math.random() * 9000)}`,
      status: 'Submitted',
      createdAt: now,
      updatedAt: now,
      history: [
        {
          status: 'Submitted',
          timestamp: now,
          note: `Availability enquiry submitted for ${data.units} unit(s) of ${data.bloodGroup} ${data.component}.`,
          actor: data.patientName,
        },
      ],
    };

    setBloodRequests((prev) => [newReq, ...prev]);
    addAuditLog('Blood', 'BLOOD_REQUEST_CREATED', `${newReq.id} created for ${data.bloodGroup} ${data.component} at ${data.centreName}`);
    return newReq;
  };

  const updateBloodRequestStatus = (requestId: string, newStatus: RequestStatus, note?: string) => {
    const now = new Date().toISOString().slice(0, 16).replace('T', ' ');
    setBloodRequests((prev) =>
      prev.map((req) => {
        if (req.id !== requestId) return req;
        const historyItem = {
          status: newStatus,
          timestamp: now,
          note: note || `Status transitioned to ${newStatus}.`,
          actor: userRole === 'admin' ? 'Dr. Verma (Nodal Officer)' : patient.name,
        };
        return {
          ...req,
          status: newStatus,
          updatedAt: now,
          history: [...req.history, historyItem],
        };
      })
    );
    addAuditLog('Blood', 'BLOOD_STATUS_UPDATED', `${requestId} marked as ${newStatus}`);
  };

  const createAmbulanceRequest = (data: Omit<AmbulanceRequest, 'id' | 'createdAt' | 'updatedAt' | 'history' | 'status'>): AmbulanceRequest => {
    const now = new Date().toISOString().slice(0, 16).replace('T', ' ');
    const newReq: AmbulanceRequest = {
      ...data,
      id: `REQ-AMB-${Math.floor(1000 + Math.random() * 9000)}`,
      status: 'Request Submitted',
      estimatedArrivalMinutes: 12,
      createdAt: now,
      updatedAt: now,
      history: [
        {
          status: 'Request Submitted',
          timestamp: now,
          note: `Pickup requested at ${data.pickupLocation} to ${data.destination}.`,
          actor: data.patientName,
        },
      ],
    };

    setAmbulanceRequests((prev) => [newReq, ...prev]);
    addAuditLog('Ambulance', 'AMBULANCE_DISPATCH_REQUESTED', `${newReq.id} placed for ${data.category} unit (${data.providerName})`);
    return newReq;
  };

  const updateAmbulanceRequestStatus = (requestId: string, newStatus: AmbulanceStatus, note?: string) => {
    const now = new Date().toISOString().slice(0, 16).replace('T', ' ');
    setAmbulanceRequests((prev) =>
      prev.map((req) => {
        if (req.id !== requestId) return req;
        const historyItem = {
          status: newStatus,
          timestamp: now,
          note: note || `Status updated to ${newStatus}.`,
          actor: userRole === 'admin' ? 'Dispatch Nodal Desk' : 'Emergency Driver',
        };
        return {
          ...req,
          status: newStatus,
          updatedAt: now,
          history: [...req.history, historyItem],
        };
      })
    );
    addAuditLog('Ambulance', 'AMBULANCE_STATUS_UPDATED', `${requestId} updated to ${newStatus}`);
  };

  const createAssistanceApplication = (
    data: Omit<AssistanceApplication, 'id' | 'createdAt' | 'updatedAt' | 'history' | 'status'>
  ): AssistanceApplication => {
    const now = new Date().toISOString().slice(0, 16).replace('T', ' ');
    const newApp: AssistanceApplication = {
      ...data,
      id: `APP-NGO-${Math.floor(1000 + Math.random() * 9000)}`,
      status: 'Submitted',
      createdAt: now,
      updatedAt: now,
      history: [
        {
          status: 'Submitted',
          timestamp: now,
          note: `Application filed under category: ${data.category} for treatment at ${data.hospitalName}.`,
          actor: data.patientName,
        },
      ],
    };

    setAssistanceApplications((prev) => [newApp, ...prev]);
    addAuditLog('Assistance', 'ASSISTANCE_APPLICATION_FILED', `${newApp.id} submitted for ${data.category} support`);
    return newApp;
  };

  const updateAssistanceStatus = (appId: string, newStatus: AssistanceStatus, note?: string) => {
    const now = new Date().toISOString().slice(0, 16).replace('T', ' ');
    setAssistanceApplications((prev) =>
      prev.map((app) => {
        if (app.id !== appId) return app;
        const historyItem = {
          status: newStatus,
          timestamp: now,
          note: note || `Review stage changed to ${newStatus}.`,
          actor: userRole === 'admin' ? 'Health Committee Reviewer' : 'Assigned Case Worker',
        };
        return {
          ...app,
          status: newStatus,
          updatedAt: now,
          history: [...app.history, historyItem],
        };
      })
    );
    addAuditLog('Assistance', 'ASSISTANCE_STATUS_UPDATED', `${appId} updated to ${newStatus}`);
  };

  const uploadDocument = (doc: Omit<MedicalDoc, 'id' | 'uploadedAt'>): MedicalDoc => {
    const now = new Date().toISOString().slice(0, 10);
    const newDoc: MedicalDoc = {
      ...doc,
      id: `DOC-2026-${Math.floor(100 + Math.random() * 900)}`,
      uploadedAt: now,
    };
    setDocuments((prev) => [newDoc, ...prev]);
    addAuditLog('Document', 'DOCUMENT_UPLOADED', `Document "${newDoc.fileName}" registered to patient profile`);
    return newDoc;
  };

  const updateDocumentAiExplanation = (docId: string, explanation: MedicalDoc['aiExplanation']) => {
    setDocuments((prev) =>
      prev.map((doc) => (doc.id === docId ? { ...doc, aiExplanation: explanation } : doc))
    );
    addAuditLog('Document', 'AI_REPORT_EXPLAINED', `Plain-language summary generated for ${docId}`);
  };

  const resetAllDemoData = () => {
    try {
      localStorage.removeItem(`${STORAGE_KEY}_user_location`);
      localStorage.removeItem(`${STORAGE_KEY}_donors`);
      localStorage.removeItem(`${STORAGE_KEY}_patient`);
      localStorage.removeItem(`${STORAGE_KEY}_blood_centres`);
      localStorage.removeItem(`${STORAGE_KEY}_ambulances`);
      localStorage.removeItem(`${STORAGE_KEY}_documents`);
      localStorage.removeItem(`${STORAGE_KEY}_blood_requests`);
      localStorage.removeItem(`${STORAGE_KEY}_ambulance_requests`);
      localStorage.removeItem(`${STORAGE_KEY}_assistance_apps`);
      localStorage.removeItem(`${STORAGE_KEY}_hospitals`);
      localStorage.removeItem(`${STORAGE_KEY}_audit_logs`);
    } catch {}

    setUserLocation({
      type: 'manual',
      state: 'Bihar',
      city: 'Darbhanga',
      approximateArea: 'Darbhanga, Bihar',
      isPermissionGranted: false,
    });
    setVolunteerDonors(INITIAL_VOLUNTEER_DONORS);
    setPatient(INITIAL_PATIENT);
    setBloodCentres(INITIAL_BLOOD_CENTRES);
    setAmbulances(INITIAL_AMBULANCES);
    setDocuments(INITIAL_DOCUMENTS);
    setBloodRequests(INITIAL_BLOOD_REQUESTS);
    setAmbulanceRequests(INITIAL_AMBULANCE_REQUESTS);
    setAssistanceApplications(INITIAL_ASSISTANCE_APPLICATIONS);
    setHospitals(INITIAL_HOSPITALS);
    setAuditLogs([
      {
        id: `LOG-${Date.now()}`,
        timestamp: new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' }),
        action: 'DATA_RESET_DEFAULT',
        entityType: 'Security',
        actor: 'Administrator',
        details: 'All demonstration records restored to factory prototype baseline.',
      },
    ]);
    setShowResetConfirmModal(false);
  };

  return (
    <AppContext.Provider
      value={{
        currentPage,
        setCurrentPage,
        language,
        setLanguage,
        t,
        userRole,
        setUserRole,
        selectedCity,
        setSelectedCity,
        publicQrPreviewToken,
        setPublicQrPreviewToken,
        userLocation,
        setUserLocation,
        requestBrowserLocation,
        setManualLocation,
        clearLocation,
        volunteerDonors,
        toggleDonorOptIn,
        registerVolunteerDonor,
        patient,
        updatePatientProfile,
        toggleSharedField,
        regenerateQrToken,
        revokeQrToken,
        bloodCentres,
        ambulances,
        documents,
        bloodRequests,
        ambulanceRequests,
        assistanceApplications,
        ngos: INITIAL_NGOS,
        govtSchemes: INITIAL_GOVT_SCHEMES,
        hospitals,
        auditLogs,
        createBloodRequest,
        updateBloodRequestStatus,
        createAmbulanceRequest,
        updateAmbulanceRequestStatus,
        createAssistanceApplication,
        updateAssistanceStatus,
        uploadDocument,
        updateDocumentAiExplanation,
        resetAllDemoData,
        showResetConfirmModal,
        setShowResetConfirmModal,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
